# Zero_Project

Hello World!
This is Project_805 (Python3)
Start by 2018.12.26.
